package me.tapeline.quailj.parser.nodes;

public class Node {
    
    public int codePos = 0;

}