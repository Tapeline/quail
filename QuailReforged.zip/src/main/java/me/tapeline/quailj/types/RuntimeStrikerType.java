package me.tapeline.quailj.types;

public enum RuntimeStrikerType {
    BREAK, RETURN, CONTINUE, EXCEPTION;
}
