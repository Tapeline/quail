package me.tapeline.quailj.debugging;

import me.tapeline.quailj.utils.StringUtils;

public abstract class TracedAction {

    public abstract String toString(int tab);

}
