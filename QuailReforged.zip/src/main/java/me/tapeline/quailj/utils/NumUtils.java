package me.tapeline.quailj.utils;

public class NumUtils {

    public static int round(double d) {
        return (int) Math.round(d);
    }

    public static int floor(double d) {
        return (int) Math.floor(d);
    }

    public static int ceil(double d) {
        return (int) Math.ceil(d);
    }

}
