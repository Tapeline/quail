# **quail** - A simple scripting language.

> ! ! !
> **Lookin' for a regex expert**
> ! ! !
> 
> Plz someone fix my regex (and lexer maybe) at `me.tapeline.quailj.lexer.Lexer` and `tokens.TokenType`. If you want, write to Issues
>

Guide for installation > https://github.com/Tapeline/quark/wiki/Installing-QuailJ

**CC BY-NC-SA 4.0**

This work is licensed under the Creative Commons «Attribution-NonCommercial-ShareAlike» 4.0 License. To view a copy of this license, visit
http://creativecommons.org/licenses/by-nc-sa/4.0/.
